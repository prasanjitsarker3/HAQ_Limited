import React from 'react';

const VideoSection = () => {
    return (
        <div>
            <h1 className=' text-4xl text-center text-yellow-900'>All Video Section In Here</h1>
        </div>
    );
};

export default VideoSection;