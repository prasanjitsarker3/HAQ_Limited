import React from 'react';

const AllVideo = () => {
    return (
        <div className=' py-5'>
            <div>
                <h1 className=' text-4xl text-center text-yellow-900'>All Video Section In Here</h1>
            </div>
        </div>
    );
};

export default AllVideo;