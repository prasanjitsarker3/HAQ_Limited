import React from 'react';
import CandidateFrom from '../CandidateFrom/CandidateFrom';

const Candidate = () => { 
    return ( 
        <div>
            <CandidateFrom></CandidateFrom>
        </div> 
    );
};

export default Candidate;