import CompanyFrom from "../CompanyFrom/CompanyFrom";

const Company = () => {

    return (
        <div className='pb-12'>
            <CompanyFrom></CompanyFrom>
        </div>
    );
};

export default Company;